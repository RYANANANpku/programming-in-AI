#include <iostream>
#include <string>
#include <memory>
#include <vector>
#include <cmath>
#include <cublas_v2.h>
#include <curand.h>

// Use 512 threads per block
const int kCudaThreadsNum = 512;
inline int CudaGetBlocks(const int N) {
   return (N + kCudaThreadsNum - 1) / kCudaThreadsNum;
}

#define CUDA_KERNEL_LOOP(i, n)                         \
  for (int i = blockIdx.x * blockDim.x + threadIdx.x;  \
       i < (n);                                        \
       i += blockDim.x * gridDim.x)

void matrix_init(float*A, int rows, int cols){
    // Create a pseudo-random number generator
    curandGenerator_t prng;
    curandCreateGenerator(&prng, CURAND_RNG_PSEUDO_DEFAULT);
    // Set the seed for the random number generator using the system clock
    curandSetPseudoRandomGeneratorSeed(prng, (unsigned long long)clock());
    // Fill the array with random numbers on the device
    curandGenerateUniform(prng, A, rows * cols);
    curandDestroyGenerator(prng);
}

void matrix_print(float* data, int size, std::string mode)
{
    if(mode == "cpu")
    {
        for(int i = 0; i < size; i++)
        {
            std::cout << data[i] << " ";
        }
        std::cout << std::endl;
    }
    else if(mode == "gpu")
    {
        float* data_cpu = (float*)malloc(size*sizeof(float));
        cudaMemcpy(data_cpu,data,size*sizeof(float),cudaMemcpyDeviceToHost);
        for(int i = 0; i < size; i++)
        {
            //if(i % 18 == 0) std::cout << std::endl;
            std::cout << data_cpu[i] << " ";
        }
        std::cout << std::endl;
        free(data_cpu);
    }
    return;
}

void gemm_gpu(cublasOperation_t op1, cublasOperation_t op2, const float *A, const float *B, float *C, const int m, const int k, const int n, float p1, float p2) 
{
    int lda,ldb,ldc = m;
    if(op1 == CUBLAS_OP_N) lda = m;
    else lda = k;
    if(op2 == CUBLAS_OP_N) ldb = k;
    else ldb = n;
    const float alf = p1, bet = p2;
    const float *alpha = &alf;
    const float *beta = &bet;
    // Create a handle for CUBLAS
    cublasHandle_t handle; cublasCreate(&handle);
    // Do the actual multiplication
    cublasSgemm(handle, op1, op2, m, n, k, alpha, A, lda, B, ldb, beta, C, ldc);
    // Destroy the handle
    cublasDestroy(handle);
}